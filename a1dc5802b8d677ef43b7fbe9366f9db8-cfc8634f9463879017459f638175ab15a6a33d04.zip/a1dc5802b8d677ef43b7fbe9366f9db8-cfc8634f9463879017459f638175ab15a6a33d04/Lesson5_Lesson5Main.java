package Lesson5;

public class Lesson5Main {

    public static void main(String[] args) {

        SpaceXN3 spaceXN3 = new SpaceXN3(2018, 200, true, 30, true);
        System.out.println(spaceXN3.maxSpeed);
        System.out.println(spaceXN3.year);
        System.out.println(spaceXN3.isDiving);
        System.out.println(spaceXN3.quantityofoxigen);
        System.out.println(spaceXN3.isDrivingoffroad);


    }
}
