package Lesson5;

public class SpaceX {
    public int year;
    public int maxSpeed;

    public SpaceX(int year, int maxSpeed) {
        this.year = year;
        this.maxSpeed = maxSpeed;

    }

}